Environment: Mac OS Sierra

I have my own tester program it's tester.c.
and my program passed my tester.c

However, I wasn't able to get it right with the makefile to add tester.c.
I tried to copy and paste to another copy of tests_pt1.c, but it give me that
list_struct is not defined.

So the makefile will only create tests_pt1 and tests_pt2 (prof's testing program)