
#ifndef _IO_H
#define _IO_H
#include "list.h"


void print_and_destroy(LIST *data); 

LIST *read_ints();

#endif
